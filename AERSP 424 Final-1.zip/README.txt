Betrayal at House on the Hill

Welcome!!

To play the game, simply extract all the provided files into a new file. Ensure that you have both Source.cpp and Characters.cpp, as both are required.
This game was made using C++ in Visual Studio in November 2023.